<?php 
require_once '../controllers/checkLogin.php';
require_once '../views/add_teacher_complete.php';
?>