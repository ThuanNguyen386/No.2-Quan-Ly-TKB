<?php

define('SPECIALIZED_ARR', [
    '001' => 'Khoa học máy tính',
    '002' => 'Khoa học dữ liệu',
    '003' => 'Hải dương học'
]);
define('DEGREE_ARR', [
    '001' => 'Cử nhân',
    '002' => 'Thạc sĩ',
    '003' => 'Tiến sĩ',
    '004' => 'Phó giáo sư',
    '005' => 'Giáo sư'
]);

$listSchool_year = [
    'y1' => 'Năm 1',
    'y2' => 'Năm 2',
    'y3' => 'Năm 3',
    'y4' => 'Năm 4',
];

$listWeek_day = [
    'd1' => 'Thứ 2',
    'd2' => 'Thứ 3',
    'd3' => 'Thứ 4',
    'd4' => 'Thứ 5',
    'd5' => 'Thứ 6',
    'd6' => 'Thứ 7',
];

?>