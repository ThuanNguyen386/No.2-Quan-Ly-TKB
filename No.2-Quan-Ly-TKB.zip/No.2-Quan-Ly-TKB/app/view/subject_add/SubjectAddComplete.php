<html>
<head>
	<title>Đăng ký môn học</title>
	<meta charset=UTF-8>
    <link rel="stylesheet" href="../../web/css/SubjectAdd.css">
</head>
<body>
    <form class="subject-complete" method="post" action="">   
        <p>Bạn đã đăng ký thành công môn học.</p>
        <a id='subject-complete' href="../view/home.php">Trở về trang chủ</a>
  </form>
</body>
</html>